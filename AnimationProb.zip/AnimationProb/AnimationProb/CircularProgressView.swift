//
//  CircularProgressView.swift
//  BopMe


import SwiftUI

struct CircularProgressView: View, Animatable
{
	var			percentComplete: Float
	@State var	FGColor: Color
	@State var	BGColor: Color

	var			animatableData: Float
	{
		get
		{
			return percentComplete
		}
		set
		{
			percentComplete = newValue
		}
	}

	init(foregroundColor: Color, backgroundColor: Color = Color.clear, percentComplete: Float)
	{
		FGColor = foregroundColor
		BGColor = backgroundColor
		self.percentComplete = percentComplete
		print("Progress control init with \(percentComplete) %")
	}

	var body: some View
	{
		Text("progressControl internal percent: \(percentComplete)")
		ZStack
		{
			Circle()
			.stroke(
				BGColor.opacity(0.5),
				lineWidth: 30
			)

			Circle()
			.trim(from: 0, to: CGFloat(percentComplete / 100))
			.stroke(
				FGColor,
				lineWidth: 30
			)
			.rotationEffect(.degrees(-90))
		}
	}
}


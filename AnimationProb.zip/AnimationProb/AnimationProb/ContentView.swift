//
//  ContentView.swift
//  AnimationProb
//


import SwiftUI

struct ContentView: View
{
	@State var progressStarted: Bool = false

    var body: some View
	{
        VStack
		{
			CircularProgressView(foregroundColor: Color.red, percentComplete: progressStarted ? 100 : 0)
				.animation(.linear(duration: 5), value: progressStarted)

			Text("Progress is \(progressStarted ? "started" : "stopped")")
			Button(action: {progressStarted.toggle()}, label: {
				Text("Toggle progress")
			})
        }
        .padding()
    }
}



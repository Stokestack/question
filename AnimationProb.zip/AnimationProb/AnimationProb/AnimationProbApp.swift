//
//  AnimationProbApp.swift
//  AnimationProb


import SwiftUI

@main
struct AnimationProbApp: App
{
    var body: some Scene
	{
        WindowGroup
		{
            ContentView()
        }
    }
}
